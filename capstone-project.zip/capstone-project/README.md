# Capstone Project: Laporan Skill Teknologi Paling Dicari

Project akhir Course 9/11 IBM Data Analyst Professional Certificate.
Skenario: firma konsultan global menerbitkan laporan tahunan tentang
skill teknologi yang paling dicari. Data: survei developer + data lowongan.

## Struktur folder

- `data/raw/survey-data-with-duplicate.csv` : data MENTAH (65.457 baris x 114 kolom, masih ada 20 baris duplikat)
- `data/clean/survey-data.csv` : data BERSIH (65.437 baris x 114 kolom, duplikat sudah dibuang)
- `analyze_survey.py` : script analisis (pandas + matplotlib), menghasilkan findings.json dan semua chart
- `findings.json` : hasil analisis terstruktur (angka-angka temuan)
- `charts/` : 8 chart analisis + 3 komposit tab dashboard

## Alur pengerjaan

1. Data collection: dataset diunduh dari URL; data lowongan diambil via Jobs API dan web scraping (BeautifulSoup).
2. Data wrangling: 20 baris duplikat ditemukan dengan `df.duplicated()` lalu dibuang
   dengan `df.drop_duplicates()` (65.457 menjadi 65.437 baris). Missing value dicek
   per kolom. Kolom multi nilai (pemisah titik koma, misal LanguageHaveWorkedWith)
   dinormalisasi dengan fungsi `count_multi`.
3. EDA: distribusi (76,7% developer profesional), korelasi (kompensasi per negara/bahasa),
   outlier (sebaran gaji miring kanan, dipakai median $65.000).
4. Visualisasi: 8 chart (bahasa teratas, tren Have vs Want, database, IDE, negara,
   kompensasi per negara, distribusi usia, platform).
5. Dashboard: 3 tab (Current Technology Usage, Future Technology Trends, Demographics).
6. Presentasi 20 slide (template resmi IBM) diekspor ke PDF untuk dinilai AI (Mark).

## Cara menjalankan ulang analisis

```
python3 analyze_survey.py
```

Membutuhkan: pandas, matplotlib, numpy. Output: findings.json + chart_*.png + dashboard_tab*.png.

## Temuan utama

- Bahasa paling dipakai: JavaScript (37.492). Paling ingin dipelajari: Python (25.047).
- Bintang naik daun: Rust (rasio Want/Have 2,28x), Go (1,708x).
- Database: PostgreSQL dominan (25.536 dipakai, 24.005 ingin dipakai).
- IDE: Visual Studio Code 42.751 pengguna (sekitar 65%).
- Median kompensasi global $65.000/tahun; AS $143.000 vs India $16.749.
- 67,9% responden yang menjawab puas dengan pekerjaannya.

## Catatan data

- Dataset tidak punya kolom gender.
- Kolom Age berupa kategori; mean/median dihitung lewat nilai tengah tiap kategori.
